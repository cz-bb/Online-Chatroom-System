// const { connect } = require('node:http2');
const ws = require('nodejs-websocket');
const port = 8090;

let count = 0;

const server = ws.createServer(connect =>{
    console.log('有用户进入');
    count++;
    connect.userName = '用户'+count;
    //通知所有用户，有新用户进入（连接）房间
    broadcast(connect.userName+'进入聊天室')

    console.log('当前人数：'+count);
    connect.on('text',data=>{
        // console.log('接收到来自用户的信息',data);
        // connect.send(data);
        broadcast(data);

    });
    connect.on('close',()=>{
        console.log('用户断开连接');
        count--;
        console.log('当前人数：'+count);
        broadcast(connect.userName+'离开了房间');

    });
    connect.on('err',()=>{
        console.log('连接异常',err);
    });

    //广播，向所有用户广播消息
    function broadcast(msg){
        //所有用户（连接着的）
        server.connections.forEach(item=>{
            item.send(msg);
        });
    }
});

server.listen(port,()=>{
    console.log('webscoket服务启动成功！监听端口：'+port);
});



