const http = require('http');
const fs = require('fs');
const urlLib = require('url');
const querystring = require('querystring');
const socket = require('socket.io');
const mysql = require('mysql');
const ws = require('nodejs-websocket');

// const { createConnection } = require('node:net');
var user_message = {};
//暂时保存要输出的用户名和密码
var user_login = {};
//暂时保存要输出的消息列表
var user_news = [];
//暂时保存要输出的好友列表
var user_friends = [];
//暂时保存要输出的群组列表
var user_chatrooms = [];
// var user_message3 = {};

//数据库连接池
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'cz_test_database'
});
//创建服务器
var server = http.createServer(function (req, res) {

    // var str = '';
    req.on('data', function (data) {
        str += data;
    });
    req.on('end', function () {
        var obj = urlLib.parse(req.url, true);//解析收到的数据
        // console.log(obj);
        const url = obj.pathname;//路径
        // console.log('url是：'+url);
        const GET = obj.query;//接收到的数据
        // console.log(GET);
        // const POSt = querystring.parse(str);
        //区分前台访问的类型：接口还是文件。
        if (url == '/') {  //接口
            switch (GET.act) {//ajax请求方式
                case 'reg': //注册
                    //检查用户是否已经存在
                    // if (users[GET.user]) {
                    //     res.write('{"ok":false,"msg":"此用户已经被注册"}');
                    //     res.end();
                    //     // console.log('wwwwwwwwwwwww');
                    // } else {
                    //     //插入users
                    //     users[GET.user] = GET.pass;
                    // res.write('{"ok":true,"msg":"注册成功"}');
                    // res.end();
                    // }
                    db.query('SELECT username FROM user_table ;', (err, data) => {
                        if (err) {
                            console.log('请求数据库失败！', err);
                        } else {
                            console.log('请求数据库成功！');
                            // console.log(JSON.stringify(data));
                            // console.log(data.indexOf('blue'));
                            // console.log(JSON.stringify(data).indexOf(GET.user));
                            // console.log(data[0].password);
                            var index = data.findIndex(function (d) {
                                return d.username == GET.user;
                            });
                            if (index == -1) {
                                // console.log('注册成功');
                                //将注册成功的用户信息插入数据库的表中保存
                                db.query("INSERT INTO user_table (ID,username,password) values (0, '" + GET.user + "','" + GET.pass + "' ) ;", (err, data) => {
                                    if (err) {
                                        console.log('修改数据库失败！', err);
                                    } else {
                                        console.log('数据库修改成功！');
                                        // console.log(data);
                                        // console.log(JSON.stringify(data[0]));
                                        //创建消息列表
                                        db.query("CREATE TABLE " + GET.user + "_messages (ID INT NOT NULL PRIMARY KEY AUTO_INCREMENT, messagename  VARCHAR(20) ); ", (err, data) => {
                                            if (err) {
                                                console.log(err);
                                            } else {
                                                console.log('创建消息列表成功');
                                                console.log(data);
                                            }
                                            //创建好友列表
                                            db.query("CREATE TABLE " + GET.user + "_friends (ID INT NOT NULL PRIMARY KEY AUTO_INCREMENT, friendname  VARCHAR(20) ); ", (err, data) => {
                                                if (err) {
                                                    console.log(err);
                                                } else {
                                                    console.log('创建好友列表成功');
                                                    console.log(data);
                                                }
                                                //创建群组列表
                                                db.query("CREATE TABLE " + GET.user + "_chatrooms (ID INT NOT NULL PRIMARY KEY AUTO_INCREMENT, chatroomname  VARCHAR(20) ); ", (err, data) => {
                                                    if (err) {
                                                        console.log(err);
                                                    } else {
                                                        console.log('创建群组列表成功');
                                                        console.log(data);
                                                    }
                                                    res.write('{"ok":true,"msg":"注册成功"}');
                                                    res.end();
                                                });
                                            });
                                        });
                                        // res.write('{"ok":true,"msg":"注册成功"}');
                                        // res.end();
                                    }
                                });
                                // console.log('注册成功');
                            } else {
                                console.log('注册失败：用户名已存在');
                                console.log(data[index]);
                                res.write('{"ok":true,"msg":"注册失败：用户名已存在"}');
                                res.end();
                            }
                            // if (JSON.stringify(data).indexOf(GET.user) != -1) {
                            //     // console.log('注册失败！');
                            //     res.write('{"ok":false,"msg":"此用户已经被注册"}');
                            //     res.end();

                            // } else {
                            //     // console.log('注册成功！');
                            // db.query("INSERT INTO user_table (ID,username,password) values (0, '" + GET.user + "','" + GET.pass + "' ) ;", (err, data) => {
                            //     if (err) {
                            //         console.log('注册失败！', err);
                            //     } else {
                            //         console.log('注册成功！');
                            //         // console.log(data[0]);
                            //         // console.log(JSON.stringify(data[0]));
                            //         res.write('{"ok":true,"msg":"注册成功"}');
                            //         res.end();
                            //     }
                            // });
                            //     // res.write('{"ok":true,"msg":"注册成功"}');
                            //     // res.end();
                            // }
                        }
                    });
                    break;
                case 'login': //登录
                    db.query("SELECT * FROM user_table;", (err, data) => {
                        if (err) {
                            console.log('请求账号列表错误！');
                        } else {
                            console.log('请求账号列表成功');
                            // console.log(data);
                            var index = data.findIndex(function (d) {
                                return d.username == GET.user;
                            });
                            // console.log(data[index]);
                            // console.log(data[index].password);
                            if (index == -1) {
                                console.log('登录失败：账号不存在');
                                res.write('{"ok":false,"msg":"登录失败：账号不存在"}');
                                res.end();
                                // console.log('账号存在，正在核对密码...');
                            } else if (data[index].password == GET.pass) {
                                console.log('密码正确，登录成功！');
                                // user_message == JSON.stringify(data[index]);
                                // console.log(data[index]);
                                // console.log(user_message);
                                user_login = Object.assign(user_message, data[index]);
                                //获取该用户的消息列表
                                db.query("SELECT * FROM " + data[index].username + "_messages;", (err, data) => {
                                    if (err) {

                                    } else {
                                        user_news = data;
                                        // console.log(user_news);
                                    }
                                });
                                //获取该用户的好友列表
                                db.query("SELECT * FROM " + data[index].username + "_friends;", (err, data) => {
                                    if (err) {

                                    } else {
                                        user_friends = data;
                                        // console.log(user_friends);
                                    }
                                });
                                //获取该用户的群组列表
                                db.query("SELECT * FROM " + data[index].username + "_chatrooms;", (err, data) => {
                                    if (err) {

                                    } else {
                                        user_chatrooms = data;
                                        // console.log(user_chatrooms);
                                    }
                                });
                                //#########################
                                res.write('{"ok":true,"msg":"密码正确，登录成功！"}');
                                // res.render('main.html',{});
                                res.end();
                            } else {
                                console.log('登陆失败：密码错误！');
                                res.write('{"ok":false,"msg":"登录失败：密码错误！"}');
                                res.end();
                            }
                            // console.log(data.indexOf(GET.user));
                            // console.log(JSON.stringify(data));
                            // console.log(JSON.stringify(data).indexOf(GET.user) != -1);
                            // if(JSON.stringify(data).indexOf(GET.user) != -1){
                            //     console.log('账号存在，正在核对密码');
                            //     db.query('SELECT password FROM user_table;',function(err,data){
                            //         if(err){
                            //             console.log('请求密码列表错误',err);
                            //         }else{
                            //             console.log('请求密码列表成功');
                            //             // console.log(data);
                            //             // console.log(JSON.stringify(data));
                            //             // console.log(eval('(' + JSON.stringify(data) + ')'));
                            //             // var czdd = eval('(' + JSON.stringify(data) + ')');
                            //             // console.log(eval('(' + JSON.stringify(data) + ')').indexOf({password:123456}));
                            //             // console.log(data.indexOf(123456));
                            //             var index = data.findIndex(function(d){
                            //                 return d.password ==GET.pass;
                            //             });
                            //             console.log(index);
                            //             console.log(data[index]);
                            //             console.log(data[index].password);
                            //             if(index==-1){
                            //                 console.log('密码错误！');
                            //             }else{
                            //                 console.log('密码正确，登录成功！');
                            //             }
                            //             // var test = {password:GET.pass};
                            //             // if(JSON.stringify(czdd[index])==JSON.stringify(test)){
                            //             //     console.log('yes');
                            //             // }else{
                            //             //     console.log('no');
                            //             // }
                            //             // res.end();
                            //             // if(JSON.stringify(data).indexOf(GET.pass) != -1){
                            //             //     console.log('密码正确,登录成功');
                            //             // }else{
                            //             //     console.log('登陆失败：密码错误');
                            //             // }
                            //         }
                            //     });
                            // }else{
                            //     console.log('账号不存在');
                            // }
                        }
                    });
                    //检查用户是否存在
                    // if (users[GET.name] == null) {
                    //     res.write('{"ok":false,"msg":"此用户不存在"}');
                    //     res.end();
                    // } else if (users[GET.user] != GET.pass) {   //检查用户密码是否正确
                    //     res.write('{"ok":false,"msg":"用户名或者密码错误！"}');
                    //     res.end();
                    // } else {
                    //     // console.log();
                    //     db.query('SELECT * FROM user_table;', (err, data) => {
                    //         if (err) {
                    //             console.log('错误！', err);
                    //         } else {
                    //             console.log('成功');
                    //             // console.log(data[0]);
                    //             // console.log(JSON.stringify(data[0]));
                    //             // console.log('{"ok":true,"msg":"登录成功"}'+JSON.stringify(data[0]));
                    //             var arr3 = Object.assign({ "ok": true, "msg": "登录成功" }, data[0]);
                    //             console.log(arr3);
                    //             var test = JSON.stringify(arr3);
                    //             console.log(test);
                    //             // res.write('Object.assign({"ok":true,"msg":"登录成功"},data[0])');
                    //             // res.write('{"ok":true,"msg":"登录成功"}');
                    //             // res.write(JSON.stringify(data[0]));
                    //             res.write(test);
                    //             res.end();

                    //         }
                    //     });
                    //     // res.write('{"ok":true,"msg":"登录成功"}');
                    //     // res.end();
                    // }
                    break;
                case 'main': //渲染
                    // console.log(user_login);
                    // console.log(user_news);
                    // console.log(user_message2.ID);
                    res.write('{"ok":true,"user":' + JSON.stringify(user_login) + ',"news_list":' + JSON.stringify(user_news) + ',"friends_list":' + JSON.stringify(user_friends) + ',"chatrooms_list":' + JSON.stringify(user_chatrooms) + '}');
                    // user_login = {};
                    // user_news = [];
                    // user_chatrooms = [];
                    // user_friends = [];
                    res.end();
                    break;
                case 'search'://搜索
                    var a = 0;
                    var b = 0;
                    //检索用户列表是否有目标用户名
                    db.query('SELECT * FROM user_table', (err, data) => {
                        if (err) {
                        } else {
                            // console.log(data);
                            var index = data.findIndex(function (d) {
                                return d.username == GET.searchValue;
                            });
                            console.log(data[index]);
                            a = index;
                            console.log('a的值：' + a);
                            //检索聊天室列表是否有目标聊天室名
                            db.query('SELECT * FROM chatroom_table', (err, data) => {
                                if (err) {
                                    console.log(err);
                                } else {
                                    // console.log(data);
                                    var index = data.findIndex(function (d) {
                                        return d.roomname == GET.searchValue;
                                    });
                                    console.log(data[index]);
                                    b = index;
                                    console.log('b的值：' + b);
                                    if (a >= 0 && b >= 0) {
                                        console.log('该用户/群聊存在');
                                        res.write('{"ok":1,"message":"找到1个用户、1个群聊！"}');
                                        res.end();
                                    } else if (a >= 0) {
                                        console.log('该用户存在');
                                        res.write('{"ok":2,"message":"找到1个用户、0个群聊！"}');
                                        res.end();
                                    } else if (b >= 0) {
                                        console.log('该群聊存在');
                                        res.write('{"ok":3,"message":"找到0个用户、1个群聊！"}');
                                        res.end();
                                    } else {
                                        console.log('该用户/群聊不存在');
                                        res.write('{"ok":-1,"message":"找到0个用户、0个群聊！"}');
                                        res.end();
                                    }
                                }
                            });
                        }
                    });
                    //检索聊天室列表是否有目标聊天室名
                    // db.query('SELECT * FROM chatroom_table', (err, data) => {
                    //     if (err) {
                    //         console.log(err);
                    //     } else {
                    //         // console.log(data);
                    //         var index = data.findIndex(function (d) {
                    //             return d.roomname == GET.searchValue;
                    //         });
                    //         console.log(data[index]);
                    //         b = index;
                    //         console.log('b的值：'+b);
                    //     }
                    // });
                    //判断搜索结果，返回提示信息
                    // if(a>=0&&b>=0){
                    //     console.log('该用户/群聊存在');
                    // }else if(a>=0){
                    //     console.log('该用户存在');
                    // }else if(b>=0){
                    //     console.log('该群聊存在');

                    // }else{
                    //     console.log('该用户/群聊不存在');

                    // }
                    // if(a<0&&b<0){
                    //     console.log('没有找到该用户/群聊');
                    // }else if(a>=0&&b>=0){
                    //     console.log('该用户/群聊存在');
                    // }else if(a>=0&&b<0){
                    //     console.log('该用户存在');
                    // }else if(a<0&&b>=0){
                    //     console.log('该群聊存在');
                    // }
                    // res.write('{"ok":true,"message":"测试成功！"}');
                    // res.end();
                    break;
                case 'addfriend'://添加好友
                    db.query("SELECT * FROM " + GET.local_name + "_friends ;", (err, data) => {
                        if (err) {
                            console.log(err);
                        } else {
                            var index = data.findIndex(function (d) {
                                return d.friendname == GET.searchValue;
                            });
                            if (index == -1) {
                                db.query("INSERT INTO " + GET.local_name + "_friends (friendname) values ( '" + GET.searchValue + "' ) ;", (err, data) => {
                                    if (err) {
                                        console.log(err);
                                    } else {
                                        // res.write('{"ok":true,"message":"添加成功！"}');
                                        // res.end();
                                    }
                                });
                                db.query("INSERT INTO " + GET.searchValue + "_friends (friendname) values ( '" + GET.local_name + "' ) ;", (err, data) => {
                                    if (err) {
                                        console.log(err);
                                    } else {

                                    }
                                });
                                res.write('{"ok":true,"message":"添加成功！"}');
                                res.end();
                            } else {
                                res.write('{"ok":false,"message":"已经有该好友"}');
                                res.end();
                            }
                        }
                    });
                    break;
                case 'addchatroom'://添加聊天室
                    console.log(GET.local_name);
                    console.log(GET.searchValue);
                    db.query('SELECT * FROM ' + GET.local_name + '_chatrooms;', (err, data) => {
                        if (err) {
                            console.log(err);
                        } else {
                            console.log(data);
                            var index = data.findIndex(function (d) {
                                return d.chatroomname == GET.searchValue;
                            });
                            if (index == -1) {
                                // console.log('添加成功！');
                                db.query("INSERT INTO " + GET.local_name + "_chatrooms (chatroomname) values ( '" + GET.searchValue + "' ) ;", (err, data) => {
                                    if (err) {
                                        console.log(err);
                                    } else {
                                        console.log('添加成功！');
                                        res.write('{"ok":true,"message":"添加成功！"}');
                                        res.end();
                                    }
                                })
                            } else {
                                console.log('已经在该群聊中');
                                res.write('{"ok":false,"message":"已经在该群聊中！"}');
                                res.end();

                            }
                        }
                    });
                    // res.write('{"ok":true,"message":"添加成功！"}');
                    // res.end();
                    break;
                case 'creatchatroom'://创建聊天室
                    db.query('SELECT * FROM chatroom_table', (err, data) => {
                        if (err) {
                            console.log(err);
                        } else {
                            console.log(data);
                            var index = data.findIndex(function (d) {
                                return d.roomname == GET.searchValue;
                            });
                            console.log(index);
                            if (index == -1) {
                                // console.log('创建群组成功！');
                                db.query("INSERT INTO chatroom_table (roomname) values ( '" + GET.searchValue + "' ) ;", (err, data) => {
                                    if (err) {
                                        console.log(err);
                                    } else {
                                        console.log('创建群组成功！');
                                        res.write('{"ok":false,"message":"创建新群聊成功！"}');
                                        res.end();
                                    }
                                });
                            } else {
                                console.log('该群聊已存在！');
                                res.write('{"ok":false,"message":"创建失败：该群聊已存在！"}');
                                res.end();
                            }
                        }
                    });
                    // res.write('{"ok":false,"message":"已经有该好友"}');
                    // res.end();
                    break;
                case 'deleteFriend'://删除好友
                    console.log(GET.friendname);
                    console.log(GET.local_name);
                    db.query("DELETE FROM " + GET.local_name + "_friends WHERE friendname='" + GET.friendname + "'", (err, data) => {
                        if (err) {
                            console.log(err);
                        } else {
                            // console.log(data);
                            db.query("DELETE FROM " + GET.friendname + "_friends WHERE friendname='" + GET.local_name + "'", (err, data) => {
                                if (err) {
                                    console.log(err);
                                } else {
                                    // console.log(data);
                                    res.write('{"ok":true,"message":"删除成功！"}');
                                    res.end();
                                }
                            });
                        }
                    });
                    break;
                case 'deleteChatroom'://删除聊天室
                    // console.log(GET.chatroomname);
                    // console.log(GET.local_name);
                    db.query("DELETE FROM " + GET.local_name + "_chatrooms WHERE chatroomname='" + GET.chatroomname + "'", (err, data) => {
                        if (err) {
                            console.log(err);
                        } else {
                            res.write('{"ok":true,"message":"删除成功！"}');
                            res.end();
                        }
                    });
                    break;
                // case 'talkTo':
                //     console.log(GET.local_name,GET.talkToFriend);
                //     res.write('{"ok":true}');
                //     res.end();
                //     break;
                default:
                    res.write('{"ok":false,"msg":"未知的act"}');
                    res.end();
            }
            // res.end();
        } else {    //访问文件
            //读取文件
            var file_name = './www' + url;
            // console.log(url);
            fs.readFile(file_name, function (err, data) {
                if (err) {
                    res.write('404');
                } else {
                    res.write(data);
                }
                res.end();
            });
        };
        // res.end();
        // console.log(users);
    });
    //返回前台
}).listen(8000);

const io = require('socket.io')(server);

io.on('connection', socket => {
    console.log('新用户连接了');
    // socket.emit('send',{name:'zs'});
    // socket.on('dd',data=>{
    //     console.log(data);
    // });
    socket.on('sendMessage', data => {
        console.log(data);
        // var talkData = data;
        // var talkObject = talkData.to;
        // io.emit('receiveAllMessage',Object.assign(talkData,allObject));
        io.emit('receiveAllMessage', data);

        // socket.emit('receiveMessage',data);
        // db.query('SELECT * FROM chatroom_table',(err,data)=>{
        //     if(err){
        //         console.log(err);
        //     }else{
        //         // console.log(data);
        //         var index = data.findIndex(function(d){
        //             return d.roomname == talkObject;
        //         });
        //         var onlyObject = {"type":"only"};
        //         var allObject = {"type":"all"};
        //         if(index==-1){
        //             io.emit('receiveOneMessage',Object.assign(talkData,onlyObject));
        //             console.log(Object.assign(talkData,onlyObject));
        //         }else{
        //             console.log(Object.assign(talkData,allObject));
        //             io.emit('receiveAllMessage',Object.assign(talkData,allObject));
        //         }
        //     }
        // });

    });

});

